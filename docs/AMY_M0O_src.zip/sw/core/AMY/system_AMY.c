/*****************************************************************************
 *   startup.c:  startup function for AMY microprocessor.
 *
 *   History
 *   2009.04.01  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/

#include "amy.h"

void SystemInit (void)
{
//
//Global configuration to make the MCU ready to run.
//E.g.: system PLL configuration; pre-boot setting.
//
//.TBD.
// 
 
};
